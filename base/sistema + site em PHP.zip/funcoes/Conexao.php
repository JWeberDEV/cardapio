<?php
$servidor = 'localhost';
$usuario  = 'seudelivery_sys';
$senha 	  = '123456mudar';
$banco    = 'seudelivery_sys';

// FUNCOES DO SISTEMA DE CADASTRO ###########

$nomesite  = 'NOMEDASUAEMPRESA';
$urlmaster = 'https://seudelivery.tech'; // APENAS A URL PRINCIPAL SEM A BARRA NO FINAL ---- ----

date_default_timezone_set('America/Sao_Paulo');